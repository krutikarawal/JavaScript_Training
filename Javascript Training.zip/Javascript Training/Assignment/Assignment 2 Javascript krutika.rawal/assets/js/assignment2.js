// Part 1
function find_format() {

  var today = new Date();
  var dd = today.getDate();

  var mm = today.getMonth() + 1;
  var yyyy = today.getFullYear();
  if (dd < 10) {
    dd = '0' + dd;
  }

  if (mm < 10) {
    mm = '0' + mm;
  }

  if (document.getElementById('date-type-1').checked) {
    today = mm + '-' + dd + '-' + yyyy;
  }
  else if (document.getElementById('date-type-2').checked) {
    today = mm + '/' + dd + '/' + yyyy;
  }
  else if (document.getElementById('date-type-3').checked) {
    today = dd + '-' + mm + '-' + yyyy;
  }
  else {
    today = dd + '/' + mm + '/' + yyyy;

  }
  document.getElementById('sel_format').innerHTML = "Date is: " + today;
}

// Part 2
function show_section(sel_option) {
  document.getElementById('div_city').style.display = 'block';

  if (sel_option == 'india') {
    document.getElementById('country_india').style.display = 'block';
    document.getElementById('country_usa').style.display = 'none';
    document.getElementById('country_china').style.display = 'none';

    document.getElementById('country_india').focus();

  }
  else if (sel_option == 'china') {
    document.getElementById('country_india').style.display = 'none';
    document.getElementById('country_usa').style.display = 'none';
    document.getElementById('country_china').style.display = 'block';
    document.getElementById('country_china').focus();
  }
  else if (sel_option == 'usa') {
    document.getElementById('country_india').style.display = 'none';
    document.getElementById('country_usa').style.display = 'block';
    document.getElementById('country_china').style.display = 'none';
    document.getElementById('country_usa').focus();
  }
}

function show_city(sel_city) {
  document.getElementById('sel_show_city').innerHTML = 'Selected City is :' + sel_city;
}

// Part 3
function select_chk() {
  var selected = [];
  var ele = document.getElementsByName('chk');
  for (var index = 0; index < ele.length; index++) {
    if (ele[index].type == 'checkbox' && ele[index].checked == true) {
      selected.push(ele[index].value);
    }
  }
  document.getElementById('sel_cnt').innerHTML = 'Selected Colour count : ' + selected.length;
}

// Part 4
function select_action(button) {
  var confirmation = confirm("Are you sure you want to delete this row?");
  if (confirmation) {
    var row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
  }
}