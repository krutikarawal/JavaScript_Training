jQuery(document).ready(function($) {

//wow init script for animate css
new WOW().init();

});

function show() {
  var first_name =  document.getElementById("first-name").value;
  var last_name =  document.getElementById("last-name").value;

  var capFName = first_name.charAt(0).toUpperCase() + first_name.slice(1).toLowerCase();
  var capSName = last_name.charAt(0).toUpperCase() + last_name.slice(1).toLowerCase();
  
  var full_name = capFName + "  " + capSName;
  document.getElementById("answer").innerHTML = full_name;
}
	 

