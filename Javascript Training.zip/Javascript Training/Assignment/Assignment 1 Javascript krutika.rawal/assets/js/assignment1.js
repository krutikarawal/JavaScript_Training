function show() {
  var first_name = document.getElementById("first-name").value;
  var last_name = document.getElementById("last-name").value;

  var capFName = first_name.charAt(0).toUpperCase() + first_name.slice(1).toLowerCase();
  var capSName = last_name.charAt(0).toUpperCase() + last_name.slice(1).toLowerCase();

  var full_name = capFName + "  " + capSName;
  document.getElementById("answer").innerHTML = full_name;
}


function replace() {
  var str = document.getElementById("inp-string").value;
  var str2 = document.getElementById("rep-word").value;
  var str3 = document.getElementById("new-word").value;
  var changestring = str.replace(str2, str3);
  document.getElementById("replace").innerText = changestring;
}


function reverseWord() {
  // Get the input word
  var word = document.getElementById("inp-word").value;

  // Reverse the characters of the word
  var reversedWord = word.split("").reverse().join("");

  // Display the reversed word
  document.getElementById("reverse").innerText = reversedWord;
}


function roundNumber() {
  // Fetch the input values
  var fractionalNumber = parseFloat(document.getElementById('frac-num').value);
  var decimalPlaces = parseInt(document.getElementById('dec-num').value);

  // Round the number using the toFixed() method
  var roundedNumber = fractionalNumber.toFixed(decimalPlaces);

  // Display the rounded number
  document.getElementById('round-num').textContent = 'Rounded Number: ' + roundedNumber;
}

//  date-time function
var today = new Date();
var day = today.getDay();
var daylist = ["Sunady", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var finalDay = daylist[day];
var hr = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var prepand = (hr >= 12) ? "PM" : "AM";
hr = (hr >= 12) ? hr - 12 : hr;
if (hr === 0 && prepand == "PM") {
  if (min === 0 && sec === 0) {
    hr = 12;
    prepand = "Noon";
  }
  else {
    hr = 12;
    prepand = "PM";
  }
}
if (hr === 0 && prepand == "AM") {
  if (min === 0 && sec === 0) {
    hr = 12;
    prepand = "Midnight";
  }
  else {
    hr = 12;
    prepand = "AM";
  }
}
document.getElementById("out").innerHTML = "Today is : " + daylist[day] + ". " + "Current time is : " + hr
  + " " + prepand + " : " + min + " : " + sec + " .";
