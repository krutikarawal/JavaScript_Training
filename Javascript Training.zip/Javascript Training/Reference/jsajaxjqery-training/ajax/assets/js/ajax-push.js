 //Browser Support Code
 function ajaxFunction() {
	var ajaxRequest;  // The variable that makes Ajax possible!
	ajaxRequest = new XMLHttpRequest();
			   
	// Create a function that will receive data
	// sent from the server and will update
	// div section in the same page.
	ajaxRequest.onreadystatechange = function() {
	
	   if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200) {
		  var ajaxDisplay = document.getElementById('ajaxDiv');
		  ajaxDisplay.innerHTML = ajaxRequest.responseText;
	   }
	}
	
	// Now get the value from user and pass it to
	// server script.
	var age = document.getElementById('age').value;
	var name = document.getElementById('name').value;
	var queryString = "age=" + age ;	
	queryString +=  "&name=" + name ;
	
	ajaxRequest.open("POST", "includes/dboperations-push.php", true);
	ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajaxRequest.send(queryString);	
 }