//Read the text from a file
function loadDoc() {

	// The variable that makes Ajax possible!
	var ajaxRequest = new XMLHttpRequest();
			   
	// Create a function that will receive data
	// sent from the server and will update
	// div section in the same page.
	ajaxRequest.onreadystatechange = function() {
	
	   if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200) {
		  var ajaxDisplay = document.getElementById('demo');
		  ajaxDisplay.innerHTML = ajaxRequest.responseText;
	   }
	}
	
	ajaxRequest.open("GET", "assets/ajax_info.txt", true);
	ajaxRequest.send(); 
}