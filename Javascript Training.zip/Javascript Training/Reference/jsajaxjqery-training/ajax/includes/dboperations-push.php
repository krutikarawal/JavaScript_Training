<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "test";
	
//Connect to MySQL Server
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

// Retrieve data from Query String
$age = trim($_POST['age']);
$name = trim($_POST['name']);

if($age == '' && $name == '')	{	
	$display_string = 'Please enter the data.';
}	else	{
		
	//build query
	$query = $conn->prepare("INSERT INTO ajax_example (name, age) VALUES (?, ?)");
	$query->bind_param("sd",$name, $age);

	//Execute query
	$qry_result = $query->execute() or die($conn->connect_error);
	$display_string = 'Data insertion is successful';

}
echo $display_string;
?>