<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "test";
	
//Connect to MySQL Server
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";


// Retrieve data from Query String
$age = trim($_GET['age_']);
$name = trim($_GET['name_']);

$display_string = 'Please enter the data.';

if($age == '' && $name == '')	{	
	
}	else	{
	//build query
	if($name != '')	{
		$query = "SELECT * FROM ajax_example WHERE age = '$age' OR name like '%$name%'";
	}	else	{
		$query = "SELECT * FROM ajax_example WHERE age = '$age'";
	}	

	//Execute query
	$qry_result = $conn->query($query) or die($conn->connect_error);
	
	if($qry_result->num_rows > 0)	{
		//Build Result String
		$display_string = "<table>";
		$display_string .= "<tr>";
		$display_string .= "<th>Id</th>";
		$display_string .= "<th>Age</th>";
		$display_string .= "<th>name</th>";
		$display_string .= "<th>date</th>";
		$display_string .= "</tr>";

		// Insert a new row in the table for each person returned
		while($row = $qry_result->fetch_assoc()) {
		   $display_string .= "<tr>";
		   $display_string .= "<td>$row[id]</td>";
		   $display_string .= "<td>$row[age]</td>";
		   $display_string .= "<td>$row[name]</td>";
		   $display_string .= "<td>$row[date]</td>";
		   $display_string .= "</tr>";
		}
		$display_string .= "</table>";
	}
}
echo $display_string;
?>