//Function to add elements
$(document).ready(function(){
	
	$("#btn1").click(function(){
		$("p").append(" <b>Appended text</b>.");
	});
	
	$("#btn2").click(function(){
		$("ol").append("<li>Appended item</li>");
	});
	
	$("#btn3").click(function(){
		$("#image").before("<b>Before</b>");
	});
	
	$("#btn4").click(function(){
		$("#image").after("<i>After</i>");
	});
  
});