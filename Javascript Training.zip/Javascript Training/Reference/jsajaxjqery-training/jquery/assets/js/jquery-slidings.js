//Function to slide
$(document).ready(function(){	
	$("#flip").click(function(){
		$("#panel").slideDown("slow");
		$("#panel").slideUp("slow");
	});
});	