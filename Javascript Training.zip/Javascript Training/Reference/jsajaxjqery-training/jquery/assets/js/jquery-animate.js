//Function to demo animation
$("button").click(function(){
    $(".animate").animate({
		left: '250px',
		opacity: '0.5',
		height: '+150px',
		width: '+150px'
	});
});