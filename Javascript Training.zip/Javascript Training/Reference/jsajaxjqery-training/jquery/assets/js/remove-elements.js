//Function to empty or remove the element
$(document).ready(function(){
	$("#empty").click(function(){
		$("#div").empty();
	});
	
	$("#remove").click(function(){
		$("#divfirst").remove();
	});
});