//jquery selector
$(document).ready(function() {
	$('#demo').html('<b>Hello, World!</b>');
	
	$('.demo').html('<b>Hello, World!</b>');
	
	$("#mydiv").click(function() {alert("Hello, world!");});
	
	 $("p").css("background-color", "yellow");
});