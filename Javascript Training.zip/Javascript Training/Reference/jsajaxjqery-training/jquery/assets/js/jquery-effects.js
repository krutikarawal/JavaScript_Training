//Show, hide andfade in effect
$(document).ready(function(){
	//Hide
	$("#hide").click(function(){
		$("p").hide();
	});

	//Show 
	$("#show").click(function(){
		$("p").show();
	});
	
	//Fade effect
	$("#fadeeffect").click(function(){
		$("#div1").fadeIn();
		$("#div2").fadeIn("slow");
		$("#div3").fadeIn(3000);
	});
});