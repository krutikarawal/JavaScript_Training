$(document).ready(function() {
	$("li").css("color", "red");
	
	$("li").css({"color":"red", "background-color":"green"});
	

    $("div:first").css("background-color", "black");
});