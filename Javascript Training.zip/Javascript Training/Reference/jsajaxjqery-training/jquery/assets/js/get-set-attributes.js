//Function to get and set attributes
$(document).ready(function() {
	//Get the title
	var title = $("em").attr("title");	
	
	//Set the title
	$("#divid").text(title);
	
	//Set the image
	$("#myimg").attr("src", "/jsajaxjqery-training/jquery/assets/images/logo.png");
	 
	//Set the class 
	$("em").addClass("selected");
    $("#myid").addClass("highlight");
});