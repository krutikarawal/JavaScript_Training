$(document).ready(function(){
	
	//get text using ajax
	$("#filedata").click(function(){
		$("#demo").load("/jsajaxjqery-training/jquery/assets/demo_test.txt #p1");
	});
	
	//Get data from database using ajax
	$("#getbutton").click(function(){
		var age = $('#age').val();
		var name = $('#name').val();
		queryString = '?age_='+age+'&name_='+name;
		$.get("/jsajaxjqery-training/jquery/includes/dboperations.php"+queryString, function(data, status){
			$("#getdata").html("Message: " + data);
		});
	});
	
	//Post data
	$("#postbutton").click(function(){
		$.post("/jsajaxjqery-training/jquery/includes/dboperations-push.php",
		{
			age: $('#age').val(),
			name: $('#name').val()
		},
		function(data,status){
			$("#getdata").html("Message: " + data);
		});
	});
});