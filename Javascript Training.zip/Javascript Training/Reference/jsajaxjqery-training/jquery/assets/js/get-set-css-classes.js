//Function add / remove class
$(document).ready(function(){
	$("#addclass").click(function(){
		$("h1, h2, p").addClass("blue");
		$("div").addClass("important");
	});
	
	$("#removeclass").click(function(){
		$("h1, h2, p").removeClass("blue");
		$("div").removeClass("important");
	});
});