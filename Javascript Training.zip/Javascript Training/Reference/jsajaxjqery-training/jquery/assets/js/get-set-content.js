//Function to get and set value
$(document).ready(function(){
	$("#btn1").click(function(){
		$('#result').html(("Text: " + $("#test").text()));
	});
	
	$("#btn2").click(function(){
		$('#result').html(("HTML: " + $("#test").html()));
	});
	
	$("button").click(function(){
		$('#resultval').html(("Value: " + $("#testval").val()));
  });
});