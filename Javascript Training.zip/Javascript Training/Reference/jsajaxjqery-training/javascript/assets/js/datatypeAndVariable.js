var counter = 123;
console.log(typeof(counter)); // "number"

var counter = false; 
console.log(typeof(counter)); // "boolean"

var counter = "Hi";
console.log(typeof(counter)); // "string"