//Show Value
function showValue() {
   var dayOfMonth = '#$#$#';
   
	if(isNaN(dayOfMonth))	{
		document.getElementById("showvalue").innerHTML = 'This is NOT number';
	} else {
		document.getElementById("showvalue").innerHTML = 'This is number';
	}
}

//Show Exponential
function showToExponential() {
	var exponential = 9.656;
	document.getElementById("exponential").innerHTML =
	exponential.toExponential() + "<br>" + 
	exponential.toExponential(2) + "<br>" + 
	exponential.toExponential(4) + "<br>" + 
	exponential.toExponential(6);
}		

//Show To Fixed
function showToFixed () {
	var fixed = 9.656;
	document.getElementById("fixed").innerHTML =
	fixed.toFixed(0) + "<br>" +
	fixed.toFixed(2) + "<br>" +
	fixed.toFixed(4) + "<br>" +
	fixed.toFixed(6);
}	

//Show To Precision
function showToPrecision () {
	var precision = 9.656;
	document.getElementById("precision").innerHTML = 
	precision.toPrecision() + "<br>" +
	precision.toPrecision(2) + "<br>" +
	precision.toPrecision(4) + "<br>" +
	precision.toPrecision(6);  
}

//Parse to integer
function showParseInt() {
	document.getElementById("parseint").innerHTML = 
	parseInt("-10") + "<br>" +
	parseInt("-10.33") + "<br>" +
	parseInt("10") + "<br>" +
	parseInt("10.33") + "<br>" +
	parseInt("10 6") + "<br>" +  
	parseInt("10 years") + "<br>" +  
	parseInt("years 10");  
}