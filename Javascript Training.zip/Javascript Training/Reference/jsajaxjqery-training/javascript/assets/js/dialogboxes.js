//Function to show alert
function Warn() {
   alert ("This is a warning message!");  
}

//Function to show confirmation
function getConfirmation() {
	var retVal = confirm("Do you want to continue ?");
	if( retVal == true ) {
		document.getElementById('result').innerHTML = "User wants to continue!";
		return true;
	} else {
		document.getElementById('result').innerHTML = "User does not want to continue!";
		return false;
	}
}