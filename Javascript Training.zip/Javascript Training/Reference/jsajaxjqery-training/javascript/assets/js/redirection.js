//Function to redirect
function Redirect() {
   window.location = "https://www.aress.com";
}

//Function to redirect after some interval
function Redirectin10sec() {
   setTimeout('Redirect()', 5000);
}            
