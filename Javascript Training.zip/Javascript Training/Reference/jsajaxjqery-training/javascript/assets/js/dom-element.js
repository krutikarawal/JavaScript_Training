//Function to get element by id
function getElementId() {
  document.getElementById("getElementId").innerHTML = "Hello World";
}

//Function to get element by class name
function getElementClass() {
  var classname = document.getElementsByClassName("example");
  classname[0].innerHTML = "Hello World!";
}

//Function to get element by name
function getElementName() {
  var elementName = document.getElementsByName("fname")[0].tagName;
  document.getElementById("getElementName").innerHTML = elementName;
}

//Function to get element by tag name
function getElementLi() {
  var liName = document.getElementsByTagName("LI");
  document.getElementById("getElementLi").innerHTML = liName[18].innerHTML + " - " + liName[19].innerHTML + " - " + liName[20].innerHTML;
}