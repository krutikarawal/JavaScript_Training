
//Calculate the string length
function stringlength()	{
	var text = "John Doe"; // String written inside quotes
	document.getElementById("stringlength").innerHTML = text;
}

//The escape sequence \" inserts a double quote in a string.
function stringescapechar()	{
	var text = "We are the so-called \"Vikings\" from the north.";
	document.getElementById("stringescapechar").innerHTML = text;
}

//You can break a code line within a text string with a backslash.
function stringlongcode()	{
	document.getElementById("stringlongcode").innerHTML = "Hello \
	is simply dummy text of the printing and typesetting industry. \
	Lorem Ipsum has been the industry's standard dummy text ever \
	since the 1500s, when an unknown printer took a galley of \
	type and scrambled it to make a type specimen book. \
	It has survived not only five centuries, but also the leap into \
	electronic typesetting, remaining essentially unchanged. \
	It was popularised in the 1960s with the release of Letraset \
	sheets containing Lorem Ipsum passages, and more recently with \
	desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum!";
}

//extracts a part of a string and returns the extracted part in a new string
function stringslice()	{
	var str = "Apple, Banana, Kiwi";
	string = str.substr(7, 6)    // Returns Banana

	var str = "Apple, Banana, Kiwi";
	strings = str.substr(-4)    // Returns Kiwi
	document.getElementById("stringslice").innerHTML = string + " - " + strings;
}	

//The replace() method replaces a specified value with another value in a string
function stringreplace()	{
	var text = "Please visit Microsoft!";
	var newText = text.replace("Microsoft", "Aress");
	document.getElementById("stringreplace").innerHTML = newText;
}

//This method is used to convert the characters within a string to uppercase
function stringtouppercase()	{
	var str = "Apples are round, and Apples are Juicy.";
	document.getElementById("stringtouppercase").innerHTML = str.toUpperCase();
	
}	