//Function get date
function getDate() {
	var dateval = new Date();
	document.getElementById("newdate").innerHTML = dateval;
}	

//Function get date
function getYear() {
	var dateval = new Date();
	document.getElementById("newyear").innerHTML = dateval.getFullYear();
}

//Function get time
function getTime() {
	var dateval = new Date();
	document.getElementById("newmonth").innerHTML = dateval.getTime();
}

//Function get date
function getDay() {
	var dateval = new Date();
	document.getElementById("newday").innerHTML = dateval.getDay();
}

//Function set year
function setFullYear() {
	var dateval = new Date();
	dateval.setFullYear(1922);
	document.getElementById("setyear").innerHTML = dateval;
}

//Function set date
function setDate() {
	var dateval = new Date();
	dateval.setDate(25);
	document.getElementById("setdate").innerHTML = dateval;
}

//Function set month
function setMonth() {
	var dateval = new Date();
	dateval.setMonth(11);
	document.getElementById("setmonth").innerHTML = dateval;
}

//Set Complete Date
function setCompleteDate() {
	var dateval = new Date(2025, 4, 2, 15, 54, 23, 100);
	document.getElementById("setCompleteDate").innerHTML = dateval;
}