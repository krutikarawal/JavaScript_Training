//Function accepting parameters
function sayHello(name = '', age = '') {
	document.getElementById('result').innerHTML = "Your name is " + name + " and you are " + age + " years old.";
}