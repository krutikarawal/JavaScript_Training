//Declare variables
var x = 5;

var y = 2;

//Do the summation
var z = x + y;

//Show the summation of above
document.getElementById("result").innerHTML = 'Addition = ' + z;