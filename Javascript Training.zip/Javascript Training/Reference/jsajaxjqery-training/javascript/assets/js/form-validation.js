//Function to validate the form
function validateForm() {
	var formvalid = document.forms["myForm"]["fname"].value;
	if (formvalid.trim() == "") {
		document.getElementById('formerror').innerHTML = "Name must be filled out.";
		return false;
	}	
}

//Function to validate the number input
function validateNumericInput() {
	// Get the value of the input field with id="numb"
	var numbervalue = document.getElementById("numb").value;

	// If it is Not a Number or less than one or greater than 10
	var text;
	if (isNaN(numbervalue) || numbervalue < 1 || numbervalue > 10) {
		text = "Input is not valid.";
	} else {
		text = "Input is valid.";
	}
	document.getElementById("demo").innerHTML = text;
}