//Declare varibles
var age = 20;

//Check the IF condition
if( age > 18 ) {
   document.getElementById("ifcondition").innerHTML = 'IF condition = You are ' + age + ' years old.';   
}

//Check If - Else condition
if( age > 18 ) {
   document.getElementById("ifelsecondition").innerHTML = 'IF ELSE condition = Qualifies for driving';
} else {
   document.getElementById("ifelsecondition").innerHTML = 'IF ELSE condition = Does not qualify for driving';
}

//Check If - else - if condition
var book = "maths";
if( book == "history" ) {
   document.getElementById("ifelseifcondition").innerHTML = "<b>IF ELSE IF condition = History Book</b>";
} else if( book == "maths" ) {
   document.getElementById("ifelseifcondition").innerHTML = "<b>IF ELSE IF condition = Maths Book</b>";
} else if( book == "economics" ) {
   document.getElementById("ifelseifcondition").innerHTML = "<b>IF ELSE IF condition = Economics Book</b>";
} else {
   document.getElementById("ifelseifcondition").innerHTML = "<b>IF ELSE IF condition = Unknown Book</b>";
}

//Check Switch condition
var grade = 'A';
switch (grade) {
   case 'A': document.getElementById("switchcondition").innerHTML = "SWITCH Condition = Good job";
   break;

   case 'B': document.getElementById("switchcondition").innerHTML = "SWITCH Condition = Pretty good";
   break;

   default: document.getElementById("switchcondition").innerHTML = "SWITCH Condition = Unknown grade";
}

//Check While Loop condition
var count = 0;
while (count < 10) {
	const node = document.createElement("li");
	const textnode = document.createTextNode(count);
	node.appendChild(textnode);
	document.getElementById("whilecondition").appendChild(node);
   count++;
}
	
//Check Do - while condition

//Check For condition

//Check For - in condition

//Check Break condition
var breakvar = 1;
while (breakvar < 20) {
	if (breakvar == 5) {
	   break;   // breaks out of loop completely
	}
	
	const node = document.createElement("li");
	const textnode = document.createTextNode(breakvar);
	node.appendChild(textnode);
	
	breakvar = breakvar + 1;
	document.getElementById("breakcondition").appendChild(node) ;
}         

//Check Continue condition
var continuevar = 0;
while (continuevar < 10) {
	
	continuevar = continuevar + 1;

	if (continuevar == 5) {
		continue;   // skip rest of the loop body
	}
	
	const node = document.createElement("li");
	const textnode = document.createTextNode(continuevar);
	node.appendChild(textnode);
	
	document.getElementById("continuecondition").appendChild(node) ;
}         
